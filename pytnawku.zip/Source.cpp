#include <iostream> 
#include <conio.h>      
#include <windows.h> 
#include <time.h>  
#include <iomanip>  
#include "ConsoleLib.h"
using namespace std;


int sSquare[4][4] =
{
	{ 1, 2, 3, 4 },
	{ 5, 6, 7, 8 },
	{ 9, 10, 11, 12 },
	{ 13, 14, 15,0 }
};

void WriteDig(int X, int Y, int sSquare)
{
	GotoXY(X, Y);
	cout << "  " << flush;
	GotoXY(X, Y);
	if (sSquare)
		cout << sSquare << flush;
}


void PrintTable()
{
	int i, w = 8;


	const unsigned char Single_Top_Left = 218;
	const unsigned char Single_Top_Right = 191;
	const unsigned char Single_Bottom_Left = 192;
	const unsigned char Single_Bottom = 193;
	const unsigned char Single_Bottom_Right = 217;
	const unsigned char Single_Center_Left = 195;
	const unsigned char Single_Center_Center = 197;
	const unsigned char Single_Center_Right = 180;
	const unsigned char Single_Horz = 196;
	const unsigned char Single_Vert = 179;
	const unsigned char Single_Center = 194;
	const unsigned char Single = 0;


	cout << Single_Top_Left;  //������ ������ �����
	for (i = 1; i <= w - 2; i++)
		cout << Single_Horz;
	cout << Single_Center;
	for (i = 1; i <= w - 2; i++)
		cout << Single_Horz;
	cout << Single_Center;
	for (i = 1; i <= w - 2; i++)
		cout << Single_Horz;
	cout << Single_Center;
	for (i = 1; i <= w - 2; i++)
		cout << Single_Horz;
	cout << Single_Top_Right << endl;




	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert << endl;




	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert << endl;




	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert << endl;





	cout << Single_Center_Left; //������ ������ �����
	for (i = 1; i <= w - 2; i++)
		cout << Single_Horz;
	cout << Single_Center_Center;
	for (i = 1; i <= w - 2; i++)
		cout << Single_Horz;
	cout << Single_Center_Center;
	for (i = 1; i <= w - 2; i++)
		cout << Single_Horz;
	cout << Single_Center_Center;
	for (i = 1; i <= w - 2; i++)
		cout << Single_Horz;
	cout << Single_Center_Right << endl;




	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert << endl;



	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert << endl;



	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert << endl;




	cout << Single_Center_Left; //������ ������ �����
	for (i = 1; i <= w - 2; i++)
		cout << Single_Horz;
	cout << Single_Center_Center;
	for (i = 1; i <= w - 2; i++)
		cout << Single_Horz;
	cout << Single_Center_Center;
	for (i = 1; i <= w - 2; i++)
		cout << Single_Horz;
	cout << Single_Center_Center;
	for (i = 1; i <= w - 2; i++)
		cout << Single_Horz;
	cout << Single_Center_Right << endl;




	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert << endl;




	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert << endl;




	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert << endl;






	cout << Single_Center_Left; //��������� ������ �����
	for (i = 1; i <= w - 2; i++)
		cout << Single_Horz;
	cout << Single_Center_Center;
	for (i = 1; i <= w - 2; i++)
		cout << Single_Horz;
	cout << Single_Center_Center;
	for (i = 1; i <= w - 2; i++)
		cout << Single_Horz;
	cout << Single_Center_Center;
	for (i = 1; i <= w - 2; i++)
		cout << Single_Horz;
	cout << Single_Center_Right << endl;



	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert << endl;




	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert << endl;



	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert;
	for (i = 1; i <= w - 2; i++)
		cout << " ";
	cout << Single_Vert << endl;


	cout << Single_Bottom_Left; // ���
	for (i = 1; i <= w - 2; i++)
		cout << Single_Horz;
	cout << Single_Bottom;
	for (i = 1; i <= w - 2; i++)
		cout << Single_Horz;
	cout << Single_Bottom;
	for (i = 1; i <= w - 2; i++)
		cout << Single_Horz;
	cout << Single_Bottom;
	for (i = 1; i <= w - 2; i++)
		cout << Single_Horz;
	cout << Single_Bottom_Right << endl;
}

//  ��������� �������� ������ � ������ �������

void Table()
{
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			WriteDig(j * 7 + 3, i * 4 + 2, sSquare[i][j]);
		}
	}
}

// ������� ��������� �� �� ��������� �������
bool Full()
{
	bool da = false;
	int count = 1;
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			if (count == 15)
				break;

			if (sSquare[i][j] != count)
				da = true;
			count++;
		}
	}
	return da;
}



void Game()
{
	const int Esc = 27;
	const int Up = 72;
	const int Left = 75;
	const int Right = 77;
	const int Down = 80;

	int count = 0;
	char str[2];

	SetColor(LightRed, Black);

	//���� 0 ����� ������
	int wi = 0, wj = 0;
	int i, j;

	for (i = 0; i < 4; i++)
	{
		for (j = 0; j < 4; j++)
		{
			if (sSquare[i][j] == 0)
			{
				wi = i;
				wj = j;
				break;
			}
		}
	}

	//������ ����� ������
	srand((unsigned)time(0));

	int code = 0;
	const int KeyUp = 1;
	const int KeyLeft = 2;
	const int KeyRight = 3;
	const int KeyDown = 4;

	do
	{

		code = rand() % 4 + 1;

		switch (code)
		{
		case KeyUp:
			if (wi != 0)
			{
				sSquare[wi][wj] = sSquare[wi - 1][wj];
				sSquare[wi - 1][wj] = 0;
				wi--;
				count++;
			}
			break;

		case KeyDown:
			if (wi < 3)
			{
				sSquare[wi][wj] = sSquare[wi + 1][wj];
				sSquare[wi + 1][wj] = 0;
				wi++;
				count++;
			}
			break;

		case KeyLeft:
			if (wj != 0)
			{
				sSquare[wi][wj] = sSquare[wi][wj - 1];
				sSquare[wi][wj - 1] = 0;
				wj--;
				count++;
			}
			break;

		case KeyRight:
			if (wj < 3)
			{
				sSquare[wi][wj] = sSquare[wi][wj + 1];
				sSquare[wi][wj + 1] = 0;
				wj++;
				count++;
			}
			break;
			system("cls");

		}
	} while (count < 999999);

	SetColor(Yellow, Black);
	PrintTable();
	SetColor(LightRed, Black);

	//  ������� � ���������� ������ ������ ��� �� ������ ����������� ������� 


	for (i = 0; i < 4; i++)
	{
		for (j = 0; j < 4; j++)
		{
			if (sSquare[i][j] == 0)
			{
				wi = i;
				wj = j;
				break;
			}
		}
	}

	//��� ��� ���� ����������� �������
	int x = wj * 7 + 3, y = wi * 4 + 2;
	count = 0;
	do
	{
		Table();
		WriteDig(x, y, 0);

		code = _getch();

		if (code == 224)
		{
			code = _getch();
		}
		switch (code)
		{
		case Up:
			if (wi != 0)
			{
				sSquare[wi][wj] = sSquare[wi - 1][wj];
				sSquare[wi - 1][wj] = 0;
				wi--;
				count++;
				WriteDig(x, y -= 4, 0);
			}
			break;

		case Down:
			if (wi < 3)
			{
				sSquare[wi][wj] = sSquare[wi + 1][wj];
				sSquare[wi + 1][wj] = 0;
				wi++;
				count++;
				WriteDig(x, y += 4, 0);
			}
			break;

		case Left:
			if (wj != 0)
			{
				sSquare[wi][wj] = sSquare[wi][wj - 1];
				sSquare[wi][wj - 1] = 0;
				wj--;
				count++;
				WriteDig(x -= 7, y, 0);
			}
			break;

		case Right:
			if (wj < 3)
			{
				sSquare[wi][wj] = sSquare[wi][wj + 1];
				sSquare[wi][wj + 1] = 0;
				wj++;
				count++;
				WriteDig(x += 7, y, 0);
			}
			break;
			system("cls");

		}
		if (!Full())
		{
			system("cls");

			for (int i = 0; i < 4; i++)
			{
				for (int j = 0; j < 4; j++)
				{
					sSquare[i][j] = 0;
				}
			}

			SetColor(LightGreen, Black);


			cout << "\n\n\t\t\t  Congratulations, you win\n" << endl;

			cout << ("\t\t\tYour steps score are: ") << count;
			cout << endl << endl;

			SetColor(LightGreen, Black);
		}

	} while (code != Esc);

	if (code == Esc)
		return;

	_getch();
}


void rusovanue()
{
	const unsigned char TextLine = 219;
	ShowCursor(false);
	SetColor(Yellow, Black);

	//�
	WriteChar(3, 1, TextLine);
	WriteChar(3, 2, TextLine);
	WriteChar(3, 3, TextLine);
	WriteChar(3, 4, TextLine);
	WriteChar(3, 5, TextLine);

	WriteChar(3, 1, TextLine);
	WriteChar(4, 1, TextLine);
	WriteChar(5, 1, TextLine);
	WriteChar(6, 1, TextLine);
	WriteChar(7, 1, TextLine);

	WriteChar(8, 1, TextLine);
	WriteChar(8, 2, TextLine);
	WriteChar(8, 3, TextLine);
	WriteChar(8, 4, TextLine);
	WriteChar(8, 5, TextLine);


	//�
	WriteChar(17, 1, TextLine);
	WriteChar(17, 2, TextLine);
	WriteChar(17, 3, TextLine);
	WriteChar(17, 4, TextLine);
	WriteChar(17, 5, TextLine);


	WriteChar(17, 1, TextLine);
	WriteChar(16, 1, TextLine);
	WriteChar(15, 1, TextLine);
	WriteChar(14, 1, TextLine);
	WriteChar(13, 1, TextLine);
	WriteChar(13, 2, TextLine);
	WriteChar(13, 3, TextLine);
	WriteChar(14, 3, TextLine);
	WriteChar(15, 3, TextLine);
	WriteChar(16, 3, TextLine);
	WriteChar(14, 3, TextLine);
	WriteChar(15, 4, TextLine);
	WriteChar(14, 5, TextLine);


	////T
	WriteChar(21, 1, TextLine);
	WriteChar(22, 1, TextLine);
	WriteChar(23, 1, TextLine);
	WriteChar(24, 1, TextLine);
	WriteChar(25, 1, TextLine);
	WriteChar(26, 1, TextLine);
	WriteChar(27, 1, TextLine);

	WriteChar(24, 2, TextLine);
	WriteChar(24, 3, TextLine);
	WriteChar(24, 4, TextLine);
	WriteChar(24, 5, TextLine);


	//////H
	WriteChar(31, 1, TextLine);
	WriteChar(31, 2, TextLine);
	WriteChar(31, 3, TextLine);
	WriteChar(31, 4, TextLine);
	WriteChar(31, 5, TextLine);

	WriteChar(32, 3, TextLine);
	WriteChar(33, 3, TextLine);
	WriteChar(34, 3, TextLine);

	WriteChar(35, 1, TextLine);
	WriteChar(35, 2, TextLine);
	WriteChar(35, 3, TextLine);
	WriteChar(35, 4, TextLine);
	WriteChar(35, 5, TextLine);


	//////A
	WriteChar(40, 1, TextLine);
	WriteChar(41, 1, TextLine);
	WriteChar(42, 1, TextLine);
	WriteChar(43, 1, TextLine);
	WriteChar(44, 1, TextLine);
	WriteChar(45, 1, TextLine);

	WriteChar(39, 1, TextLine);
	WriteChar(39, 2, TextLine);
	WriteChar(39, 3, TextLine);
	WriteChar(39, 4, TextLine);
	WriteChar(39, 5, TextLine);

	WriteChar(45, 1, TextLine);
	WriteChar(45, 2, TextLine);
	WriteChar(45, 3, TextLine);
	WriteChar(45, 4, TextLine);
	WriteChar(45, 5, TextLine);

	WriteChar(39, 3, TextLine);
	WriteChar(40, 3, TextLine);
	WriteChar(41, 3, TextLine);
	WriteChar(42, 3, TextLine);
	WriteChar(43, 3, TextLine);
	WriteChar(44, 3, TextLine);

	////�

	WriteChar(49, 1, TextLine);
	WriteChar(49, 2, TextLine);
	WriteChar(49, 3, TextLine);
	WriteChar(49, 4, TextLine);
	WriteChar(49, 5, TextLine);


	WriteChar(50, 5, TextLine);
	WriteChar(51, 5, TextLine);
	WriteChar(52, 5, TextLine);
	WriteChar(53, 5, TextLine);
	WriteChar(54, 5, TextLine);
	WriteChar(55, 5, TextLine);
	WriteChar(56, 5, TextLine);
	WriteChar(57, 5, TextLine);


	WriteChar(57, 5, TextLine);
	WriteChar(57, 4, TextLine);
	WriteChar(57, 3, TextLine);
	WriteChar(57, 2, TextLine);
	WriteChar(57, 1, TextLine);

	WriteChar(53, 5, TextLine);
	WriteChar(53, 4, TextLine);
	WriteChar(53, 3, TextLine);
	WriteChar(53, 2, TextLine);
	WriteChar(53, 1, TextLine);

	////�
	WriteChar(61, 1, TextLine);
	WriteChar(61, 2, TextLine);
	WriteChar(61, 3, TextLine);
	WriteChar(61, 4, TextLine);
	WriteChar(61, 5, TextLine);

	WriteChar(62, 3, TextLine);
	WriteChar(63, 2, TextLine);
	WriteChar(64, 1, TextLine);
	WriteChar(63, 4, TextLine);
	WriteChar(64, 5, TextLine);

	////�
	WriteChar(68, 1, TextLine);
	WriteChar(68, 2, TextLine);
	WriteChar(68, 3, TextLine);
	WriteChar(68, 4, TextLine);
	WriteChar(68, 5, TextLine);

	WriteChar(69, 5, TextLine);
	WriteChar(70, 4, TextLine);
	WriteChar(71, 3, TextLine);
	WriteChar(72, 2, TextLine);
	WriteChar(73, 1, TextLine);

	WriteChar(74, 1, TextLine);
	WriteChar(74, 2, TextLine);
	WriteChar(74, 3, TextLine);
	WriteChar(74, 4, TextLine);
	WriteChar(74, 5, TextLine);
}

void help(int x, int y)
{
	SetColor(Cyan, Black);
	GotoXY(1, 1);
	cout << "Instruction how to play barley-break:";
	GotoXY(x, y + 1);
	cout << "Key Up" " =  Up ";
	GotoXY(x, y + 2);
	cout << "Key Down" " =  Down ";
	GotoXY(x, y + 3);
	cout << "Key Left" " =  Left ";
	GotoXY(x, y + 4);
	cout << "Key Right" " =  Right ";
	GotoXY(x, y + 5);
	cout << "Esc" " =  Stop the game \n\n";
}

void WriteMenu()
{
	const unsigned char LeftTop = 201;
	const unsigned char Horz = 205;
	const unsigned char Vert = 186;
	const unsigned char RightTop = 187;
	const unsigned char LeftBottom = 200;
	const unsigned char RightBottom = 188;

	WriteChar(26, 8, LeftTop);
	WriteChars(27, 8, Horz, 20);
	WriteChar(47, 8, RightTop);

	WriteChar(26, 9, Vert);
	WriteChars(27, 9, ' ', 20);
	WriteChar(47, 9, Vert);

	WriteChar(26, 10, Vert);
	WriteStr(27, 10, "\t   Play        ");
	WriteChar(47, 10, Vert);

	WriteChar(26, 11, Vert);
	WriteStr(27, 11, "\t   Help        ");
	WriteChar(47, 11, Vert);

	WriteChar(26, 12, Vert);
	WriteStr(27, 12, "\t   Quit        ");
	WriteChar(47, 12, Vert);

	WriteChar(26, 13, Vert);
	WriteChars(27, 13, ' ', 20);
	WriteChar(47, 13, Vert);

	WriteChar(26, 14, LeftBottom);
	WriteChars(27, 14, Horz, 20);
	WriteChar(47, 14, RightBottom);
}

void menu()
{
	const int Esc = 27;
	const int Enter = 13;
	int key;

	ShowCursor(false);
	SetColor(Yellow, Black);
	SetColor(White, Black);
	WriteMenu();
	const int itemCount = 3;
	int curItem = 1;
	do
	{
		ChangeTextAttr(27, 9 + curItem, LightGreen, Black, 20);

		key = _getch();
		if (key == Enter)
		{
			switch (curItem)
			{
			case 1:
				system("cls");
				Game();
				break;
			case 2:
				system("cls");
				help(2, 2);
				menu();
				break;
			case 3:
				system("cls");
				exit;
				break;
			}
		}
		if (key == 0 || key == 0xE0)
		{
			key = _getch();
			ChangeTextAttr(27, 9 + curItem, White, Black, 30);

			switch (key)
			{
			case 71:		// Home
				curItem = 1;
				break;
			case 72:		// Up
				if (curItem == 1)
					curItem = itemCount;
				else
					curItem--;
				break;
			case 79:		// End
				curItem = itemCount;
				break;
			case 80:		// Down
				if (curItem == itemCount)
					curItem = 1;
				else
					curItem++;
				break;
			}
		}
	} while (key != Enter);
}

void main()
{
	rusovanue();
	menu();
}


